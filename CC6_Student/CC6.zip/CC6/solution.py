"""
Name:
Coding Challenge 6
CSE 331 Spring 2021
Professor Sebnem Onsay
"""


def gates_needed(departures, arrivals):
    """
    ADD DOCSTRING HERE
    """
    pass
